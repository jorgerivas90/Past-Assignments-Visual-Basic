﻿Public Class Form1
    Private Sub BoxesBindingNavigatorSaveItem_Click(sender As Object, e As EventArgs) Handles BoxesBindingNavigatorSaveItem.Click
        Try
            Me.Validate()
            Me.BoxesBindingSource.EndEdit()
            Me.TableAdapterManager.UpdateAll(Me.MusicBoxesDataSet)
            MessageBox.Show("Changes Saved.", "Music Box",
                            MessageBoxButtons.OK, MessageBoxIcon.Information)
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Music Box",
                        MessageBoxButtons.OK, MessageBoxIcon.Information)


        End Try
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'MusicBoxesDataSet.Boxes' table. You can move, or remove it, as needed.
        Me.BoxesTableAdapter.Fill(Me.MusicBoxesDataSet.Boxes)

    End Sub
End Class
