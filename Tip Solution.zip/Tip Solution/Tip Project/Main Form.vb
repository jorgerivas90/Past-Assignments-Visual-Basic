﻿' Name:         Tip Project
' Purpose:      Calculate and display a server's tip.
' Programmer:   Jorge  on 03/07/2021


Public Class frmMain

    Private Sub btnCalc_Click(sender As Object, e As EventArgs) Handles btnCalc.Click
        ' Calculates and displays a server's tip.

        ' Declare Decimal variables.
        Dim dblPercentage As Double
        Dim dblBill As Double
        Dim dblTip As Double

        ' Convert txtBill.Text and txtPercentage.Text to numbers.
        Double.TryParse(txtBill.Text, dblBill)
        Double.TryParse(txtPercentage.Text, dblPercentage)

        ' Calculate the tip.
        dblPercentage = dblPercentage * 0.01
        dblTip = dblPercentage * dblBill

        ' Display the tip with a dollar sign and two decimal places.
        lblTip.Text = dblTip.ToString("C")

    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

End Class
