﻿Public Class frmMain
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub btnDisplay_Click(sender As Object, e As EventArgs) Handles btnDisplay.Click

        Dim blnTwinChosen As Boolean
        Dim blnFullChosen As Boolean
        Dim blnQueenChosen As Boolean
        Dim blnKingChosen As Boolean

        Dim decTotalCost As Decimal

        Dim decTwinCost As Decimal = 39.99D
        Dim decFullCost As Decimal = 49.99D
        Dim decQueenCost As Decimal = 49.99D
        Dim decKingCost As Decimal = 69.99D


        'Get Data from screen and place in memory variables
        blnTwinChosen = optTwin.Checked
        blnFullChosen = optFull.Checked
        blnQueenChosen = optQueen.Checked
        blnKingChosen = optKing.Checked

        'Determine which option was selected

        If blnTwinChosen = True And chkStore.Checked Then
            decTotalCost = decTwinCost
        ElseIf blnTwinChosen = True Then
            decTotalCost = decTwinCost + 5
        ElseIf blnFullChosen = True And chkStore.Checked Then
            decTotalCost = decFullCost
        ElseIf blnFullChosen = True Then
            decTotalCost = decFullCost + 5
        ElseIf blnQueenChosen = True And chkStore.Checked Then
            decTotalCost = decQueenCost
        ElseIf blnQueenChosen = True Then
            decTotalCost = decQueenCost + 5
        ElseIf blnKingChosen = True And chkStore.Checked Then
            decTotalCost = decQueenCost
        Else
            decTotalCost = decKingCost + 5
        End If

        'Display Cost on the screen

        lblCostAmount.Text = decTotalCost.ToString("C2")

    End Sub
End Class
