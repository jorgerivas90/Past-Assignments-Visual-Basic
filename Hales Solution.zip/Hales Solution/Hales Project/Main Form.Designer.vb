﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.btnDisplay = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.lblCostAmount = New System.Windows.Forms.Label()
        Me.lblCost = New System.Windows.Forms.Label()
        Me.optTwin = New System.Windows.Forms.RadioButton()
        Me.optFull = New System.Windows.Forms.RadioButton()
        Me.optQueen = New System.Windows.Forms.RadioButton()
        Me.optKing = New System.Windows.Forms.RadioButton()
        Me.chkStore = New System.Windows.Forms.CheckBox()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.optKing)
        Me.GroupBox1.Controls.Add(Me.optQueen)
        Me.GroupBox1.Controls.Add(Me.optFull)
        Me.GroupBox1.Controls.Add(Me.optTwin)
        Me.GroupBox1.Location = New System.Drawing.Point(49, 49)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(155, 237)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Size"
        '
        'btnDisplay
        '
        Me.btnDisplay.Location = New System.Drawing.Point(384, 186)
        Me.btnDisplay.Name = "btnDisplay"
        Me.btnDisplay.Size = New System.Drawing.Size(136, 41)
        Me.btnDisplay.TabIndex = 1
        Me.btnDisplay.Text = "Display Cost"
        Me.btnDisplay.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(384, 245)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(136, 41)
        Me.btnExit.TabIndex = 2
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'lblCostAmount
        '
        Me.lblCostAmount.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.lblCostAmount.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblCostAmount.Location = New System.Drawing.Point(391, 97)
        Me.lblCostAmount.Name = "lblCostAmount"
        Me.lblCostAmount.Size = New System.Drawing.Size(119, 28)
        Me.lblCostAmount.TabIndex = 3
        '
        'lblCost
        '
        Me.lblCost.AutoSize = True
        Me.lblCost.Location = New System.Drawing.Point(387, 77)
        Me.lblCost.Name = "lblCost"
        Me.lblCost.Size = New System.Drawing.Size(46, 20)
        Me.lblCost.TabIndex = 4
        Me.lblCost.Text = "Cost:"
        '
        'optTwin
        '
        Me.optTwin.AutoSize = True
        Me.optTwin.Location = New System.Drawing.Point(6, 28)
        Me.optTwin.Name = "optTwin"
        Me.optTwin.Size = New System.Drawing.Size(66, 24)
        Me.optTwin.TabIndex = 5
        Me.optTwin.TabStop = True
        Me.optTwin.Text = "Twin"
        Me.optTwin.UseVisualStyleBackColor = True
        '
        'optFull
        '
        Me.optFull.AutoSize = True
        Me.optFull.Location = New System.Drawing.Point(6, 76)
        Me.optFull.Name = "optFull"
        Me.optFull.Size = New System.Drawing.Size(59, 24)
        Me.optFull.TabIndex = 6
        Me.optFull.TabStop = True
        Me.optFull.Text = "Full"
        Me.optFull.UseVisualStyleBackColor = True
        '
        'optQueen
        '
        Me.optQueen.AutoSize = True
        Me.optQueen.Location = New System.Drawing.Point(6, 127)
        Me.optQueen.Name = "optQueen"
        Me.optQueen.Size = New System.Drawing.Size(82, 24)
        Me.optQueen.TabIndex = 7
        Me.optQueen.TabStop = True
        Me.optQueen.Text = "Queen"
        Me.optQueen.UseVisualStyleBackColor = True
        '
        'optKing
        '
        Me.optKing.AutoSize = True
        Me.optKing.Location = New System.Drawing.Point(6, 177)
        Me.optKing.Name = "optKing"
        Me.optKing.Size = New System.Drawing.Size(65, 24)
        Me.optKing.TabIndex = 8
        Me.optKing.TabStop = True
        Me.optKing.Text = "King"
        Me.optKing.UseVisualStyleBackColor = True
        '
        'chkStore
        '
        Me.chkStore.AutoSize = True
        Me.chkStore.Location = New System.Drawing.Point(391, 29)
        Me.chkStore.Name = "chkStore"
        Me.chkStore.Size = New System.Drawing.Size(145, 24)
        Me.chkStore.TabIndex = 5
        Me.chkStore.Text = "Pick up in Store"
        Me.chkStore.UseVisualStyleBackColor = True
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.chkStore)
        Me.Controls.Add(Me.lblCost)
        Me.Controls.Add(Me.lblCostAmount)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnDisplay)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "frmMain"
        Me.Text = "Hales"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents btnDisplay As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents optKing As RadioButton
    Friend WithEvents optQueen As RadioButton
    Friend WithEvents optFull As RadioButton
    Friend WithEvents optTwin As RadioButton
    Friend WithEvents lblCostAmount As Label
    Friend WithEvents lblCost As Label
    Friend WithEvents chkStore As CheckBox
End Class
