﻿' Name:         Sod Project
' Purpose:      Display the number of sod price
' Programmer:   Jorge on 5/20/2021

Public Class Form1
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()

    End Sub

    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        Dim SodArea As Rectangle
        Dim intLength As Integer
        Dim intWidth As Integer
        Dim intSodPrice As Integer
        Dim intEntireArea As Integer
        Dim dblSodTotalPrice As Double

        Integer.TryParse(txtLength.Text, intLength)
        Integer.TryParse(txtWidth.Text, intWidth)
        Integer.TryParse(txtSodPrice.Text, intSodPrice)
        If intLength > 0 AndAlso intWidth > 0 Then
            'Instantiate and initilize objects
            SodArea = New Rectangle(intLength, intLength)

            'Calculate Area
            intEntireArea = SodArea.GetArea

            'Calculate total Sod
            dblSodTotalPrice = intEntireArea * intSodPrice
        End If
        ' Display total price
        lblTotalPrice.Text = dblSodTotalPrice.ToString("N1")
    End Sub
End Class
