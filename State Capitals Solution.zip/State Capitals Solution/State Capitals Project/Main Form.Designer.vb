﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.radMaryland = New System.Windows.Forms.RadioButton()
        Me.radMontana = New System.Windows.Forms.RadioButton()
        Me.radMaine = New System.Windows.Forms.RadioButton()
        Me.radMichigan = New System.Windows.Forms.RadioButton()
        Me.radNebraska = New System.Windows.Forms.RadioButton()
        Me.btnDisplay = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.lblCapitalName = New System.Windows.Forms.Label()
        Me.lblCapital = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'radMaryland
        '
        Me.radMaryland.AutoSize = True
        Me.radMaryland.Location = New System.Drawing.Point(70, 69)
        Me.radMaryland.Name = "radMaryland"
        Me.radMaryland.Size = New System.Drawing.Size(98, 24)
        Me.radMaryland.TabIndex = 0
        Me.radMaryland.TabStop = True
        Me.radMaryland.Text = "Maryland"
        Me.radMaryland.UseVisualStyleBackColor = True
        '
        'radMontana
        '
        Me.radMontana.AutoSize = True
        Me.radMontana.Location = New System.Drawing.Point(70, 129)
        Me.radMontana.Name = "radMontana"
        Me.radMontana.Size = New System.Drawing.Size(97, 24)
        Me.radMontana.TabIndex = 1
        Me.radMontana.TabStop = True
        Me.radMontana.Text = "Montana"
        Me.radMontana.UseVisualStyleBackColor = True
        '
        'radMaine
        '
        Me.radMaine.AutoSize = True
        Me.radMaine.Location = New System.Drawing.Point(70, 179)
        Me.radMaine.Name = "radMaine"
        Me.radMaine.Size = New System.Drawing.Size(77, 24)
        Me.radMaine.TabIndex = 2
        Me.radMaine.TabStop = True
        Me.radMaine.Text = "Maine"
        Me.radMaine.UseVisualStyleBackColor = True
        '
        'radMichigan
        '
        Me.radMichigan.AutoSize = True
        Me.radMichigan.Location = New System.Drawing.Point(70, 233)
        Me.radMichigan.Name = "radMichigan"
        Me.radMichigan.Size = New System.Drawing.Size(97, 24)
        Me.radMichigan.TabIndex = 3
        Me.radMichigan.TabStop = True
        Me.radMichigan.Text = "Michigan"
        Me.radMichigan.UseVisualStyleBackColor = True
        '
        'radNebraska
        '
        Me.radNebraska.AutoSize = True
        Me.radNebraska.Location = New System.Drawing.Point(70, 289)
        Me.radNebraska.Name = "radNebraska"
        Me.radNebraska.Size = New System.Drawing.Size(102, 24)
        Me.radNebraska.TabIndex = 4
        Me.radNebraska.TabStop = True
        Me.radNebraska.Text = "Nebraska"
        Me.radNebraska.UseVisualStyleBackColor = True
        '
        'btnDisplay
        '
        Me.btnDisplay.Location = New System.Drawing.Point(257, 347)
        Me.btnDisplay.Name = "btnDisplay"
        Me.btnDisplay.Size = New System.Drawing.Size(93, 50)
        Me.btnDisplay.TabIndex = 5
        Me.btnDisplay.Text = "Display"
        Me.btnDisplay.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(410, 347)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(93, 50)
        Me.btnExit.TabIndex = 7
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'lblCapitalName
        '
        Me.lblCapitalName.AutoSize = True
        Me.lblCapitalName.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCapitalName.Location = New System.Drawing.Point(263, 177)
        Me.lblCapitalName.Name = "lblCapitalName"
        Me.lblCapitalName.Size = New System.Drawing.Size(87, 25)
        Me.lblCapitalName.TabIndex = 8
        Me.lblCapitalName.Text = "Capital:"
        '
        'lblCapital
        '
        Me.lblCapital.AutoSize = True
        Me.lblCapital.Location = New System.Drawing.Point(372, 179)
        Me.lblCapital.Name = "lblCapital"
        Me.lblCapital.Size = New System.Drawing.Size(0, 20)
        Me.lblCapital.TabIndex = 10
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.lblCapital)
        Me.Controls.Add(Me.lblCapitalName)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnDisplay)
        Me.Controls.Add(Me.radNebraska)
        Me.Controls.Add(Me.radMichigan)
        Me.Controls.Add(Me.radMaine)
        Me.Controls.Add(Me.radMontana)
        Me.Controls.Add(Me.radMaryland)
        Me.Name = "frmMain"
        Me.Text = "State Capitals"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents radMaryland As RadioButton
    Friend WithEvents radMontana As RadioButton
    Friend WithEvents radMaine As RadioButton
    Friend WithEvents radMichigan As RadioButton
    Friend WithEvents radNebraska As RadioButton
    Friend WithEvents btnDisplay As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents lblCapitalName As Label
    Friend WithEvents lblCapital As Label
End Class
