﻿Public Class frmMain
    Private Sub btnDisplay_Click(sender As Object, e As EventArgs) Handles btnDisplay.Click

        If radMaryland.Checked = True Then
            lblCapital.Text = "Annapolis"
        ElseIf radMontana.Checked = True Then
            lblCapital.Text = "Helena"
        ElseIf radMaine.Checked = True Then
            lblCapital.Text = "Augusta"
        ElseIf radNebraska.Checked = True Then
            lblCapital.Text = "Lincoln"
        ElseIf radMichigan.Checked = True Then
            lblCapital.Text = "Lansing"
        End If

    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class
