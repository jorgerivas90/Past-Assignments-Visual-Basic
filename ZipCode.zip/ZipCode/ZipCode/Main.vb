﻿Public Class Shipping
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub btnDisplay_Click(sender As Object, e As EventArgs) Handles btnDisplay.Click
        Dim strZipCode As String
        Dim strShipCharge As String
        Dim strZipCodeThree As String

        strZipCode = txtZipCode.Text.Trim

        If strZipCode.Length = 0 Then
            MessageBox.Show("Zip code must be entered")
        Else
            If strZipCode.Length < 5 Or strZipCode.Length > 5 Then
                MessageBox.Show("Please enter only 5 digits")
            Else
                strZipCodeThree = strZipCode.Substring(0, 3)
                Select Case strZipCodeThree
                    Case "605"
                        strShipCharge = 25
                    Case "606"
                        strShipCharge = 30
                    Case Else
                        MessageBox.Show("Invalid Zip Code")
                End Select
                lblShippingAmt.Text = strShipCharge

            End If
        End If

    End Sub
End Class
