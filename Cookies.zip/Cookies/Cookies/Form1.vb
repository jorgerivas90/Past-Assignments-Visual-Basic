﻿Public Class Form1
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub btnDisplay_Click(sender As Object, e As EventArgs) Handles btnDisplay.Click
        Static intCandy(4) As Integer

        Dim intSold As Integer
        Dim intChocolateSold As Integer
        Dim intOatmealSold As Integer
        Dim intSugarSold As Integer
        Dim intPeanutButterSold As Integer
        Dim inFile As IO.StreamReader
        Dim strCategory As String


        If IO.File.Exists("cookieSales.txt") Then
            inFile = IO.File.OpenText("cookieSales.txt")
            Do Until inFile.Peek = -1
                strCategory = inFile.ReadLine
                If strCategory = "Chocolate chip" Then
                    Integer.TryParse(inFile.ReadLine, intSold)
                    intChocolateSold += intSold
                    intCandy(0) = intChocolateSold
                ElseIf strCategory = "Oatmeal" Then
                    Integer.TryParse(inFile.ReadLine, intSold)
                    intOatmealSold += intSold
                    intCandy(1) = intOatmealSold
                ElseIf strCategory = "Peanut butter" Then
                    Integer.TryParse(inFile.ReadLine, intSold)
                    intPeanutButterSold += intSold
                    intCandy(2) = intPeanutButterSold
                ElseIf strCategory = "Sugar" Then
                    Integer.TryParse(inFile.ReadLine, intSold)
                    intSugarSold += intSold
                    intCandy(3) = intSugarSold
                End If
            Loop
            inFile.Close()

        End If

        lblChocolateChip.Text = intCandy(0).ToString
        lblOatmeal.Text = intCandy(1).ToString
        lblPeanutButter.Text = intCandy(2).ToString
        lblSugar.Text = intCandy(3).ToString
    End Sub


End Class
