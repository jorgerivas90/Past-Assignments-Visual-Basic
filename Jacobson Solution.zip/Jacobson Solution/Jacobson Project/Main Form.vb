﻿' Name:         Jorge Rivas
' Purpose:      Calculate and display the sales tax and total due.
' Programmer:   Jorge on 2/28/2021

Public Class frmMain
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub


End Class
