﻿' Name:         Proper Case Project
' Purpose:      Displays the name using proper case.
' Programmer:   Jorge on 4/24/2021

Option Explicit On
Option Strict On
Option Infer Off

Public Class frmMain
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub txtName_Enter(sender As Object, e As EventArgs) Handles txtName.Enter
        txtName.SelectAll()
    End Sub

    Private Sub txtName_TextChanged(sender As Object, e As EventArgs) Handles txtName.TextChanged
        lblName.Text = String.Empty
    End Sub

    Private Sub btnProper_Click(sender As Object, e As EventArgs) Handles btnProper.Click
        Dim strName As String
        Dim strFirstName As String
        Dim strLastName As String
        Dim intIndex As Integer

        txtName.Text = txtName.Text.Replace("  ", "")
        strName = txtName.Text.Trim()
        intIndex = strName.IndexOf(" ")


        If intIndex <> -1 Then
            strFirstName = strName.Substring(0, 1).ToUpper() + strName.Substring(1, intIndex).ToLower

            strLastName = strName.Substring(intIndex, 2).ToUpper + strName.Substring(intIndex + 2).ToLower

            lblName.Text = strFirstName & "" & strLastName

        ElseIf intIndex <> 0 Then
            strFirstName = strName.Substring(0, 1).ToUpper() + strName.Remove(0, 1)
            lblName.Text = strFirstName

        Else
            ' MessageBox.Show("You have not correctly input a name", 
            'MessageBoxButtons.OK,
            'MessageBoxIcon.Information)

            txtName.Focus()
        End If

    End Sub
End Class
