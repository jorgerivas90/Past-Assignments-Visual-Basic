﻿' Name:         Charleston Sales Project
' Purpose:      Display the data from two tables.
' Programmer:   <your name> on <current date>

Option Explicit On
Option Strict On
Option Infer Off

Public Class frmMain
    Private Sub frmMain_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'CharlestonDataSet.Salesperson' table. You can move, or remove it, as needed.
        Me.SalespersonTableAdapter.Fill(Me.CharlestonDataSet.Salesperson)

    End Sub
End Class
