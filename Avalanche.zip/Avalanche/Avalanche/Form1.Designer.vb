﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.lstSnowfall = New System.Windows.Forms.ListBox()
        Me.lblThing = New System.Windows.Forms.Label()
        Me.btnCalculate = New System.Windows.Forms.Button()
        Me.lblTotalSnowfallAmt = New System.Windows.Forms.Label()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(58, 73)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(252, 268)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'lstSnowfall
        '
        Me.lstSnowfall.FormattingEnabled = True
        Me.lstSnowfall.ItemHeight = 20
        Me.lstSnowfall.Location = New System.Drawing.Point(412, 73)
        Me.lstSnowfall.Name = "lstSnowfall"
        Me.lstSnowfall.Size = New System.Drawing.Size(158, 184)
        Me.lstSnowfall.TabIndex = 1
        '
        'lblThing
        '
        Me.lblThing.AutoSize = True
        Me.lblThing.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblThing.ForeColor = System.Drawing.SystemColors.Highlight
        Me.lblThing.Location = New System.Drawing.Point(51, 33)
        Me.lblThing.Name = "lblThing"
        Me.lblThing.Size = New System.Drawing.Size(445, 37)
        Me.lblThing.TabIndex = 2
        Me.lblThing.Text = "Total Snowfall in Anchorage"
        '
        'btnCalculate
        '
        Me.btnCalculate.BackColor = System.Drawing.SystemColors.Highlight
        Me.btnCalculate.ForeColor = System.Drawing.SystemColors.HighlightText
        Me.btnCalculate.Location = New System.Drawing.Point(412, 357)
        Me.btnCalculate.Name = "btnCalculate"
        Me.btnCalculate.Size = New System.Drawing.Size(158, 50)
        Me.btnCalculate.TabIndex = 3
        Me.btnCalculate.Text = "Calculate Snowfall"
        Me.btnCalculate.UseVisualStyleBackColor = False
        '
        'lblTotalSnowfallAmt
        '
        Me.lblTotalSnowfallAmt.AutoSize = True
        Me.lblTotalSnowfallAmt.Location = New System.Drawing.Point(428, 299)
        Me.lblTotalSnowfallAmt.Name = "lblTotalSnowfallAmt"
        Me.lblTotalSnowfallAmt.Size = New System.Drawing.Size(0, 20)
        Me.lblTotalSnowfallAmt.TabIndex = 4
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.lblTotalSnowfallAmt)
        Me.Controls.Add(Me.btnCalculate)
        Me.Controls.Add(Me.lblThing)
        Me.Controls.Add(Me.lstSnowfall)
        Me.Controls.Add(Me.PictureBox1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents lstSnowfall As ListBox
    Friend WithEvents lblThing As Label
    Friend WithEvents btnCalculate As Button
    Friend WithEvents lblTotalSnowfallAmt As Label
End Class
