﻿Public Class Form1
    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        Dim strSnowfallAmt As String
        Dim decSnowfallAmt As Decimal = 0
        Dim decTotalSnowfall As Decimal = 0
        Dim intLoopCounter As Integer = 1

        Do Until intLoopCounter > 7
            strSnowfallAmt = InputBox("Enter the snowfall for Month number" & intLoopCounter, "Enter average snowfall")
            decSnowfallAmt = Convert.ToDecimal(strSnowfallAmt) ' convert snowfall text amoun tto decimal equivalent
            lstSnowfall.Items.Add(decSnowfallAmt) ' add amount user provided to the list
            decTotalSnowfall = decTotalSnowfall + decSnowfallAmt ' add amount user proivded to accumulator
            intLoopCounter = intLoopCounter + 1 '  Increase counter to prevent memory overflow

        Loop
        lblTotalSnowfallAmt.Text = "The total snowfall is " & decTotalSnowfall.ToString("F1")

    End Sub
End Class
