﻿'Name: Florist Project
'Purpose: Display store information
'Programmer: Jorge Rivas 2/22/2021
Public Class fromMain
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub btnShow_Click(sender As Object, e As EventArgs) Handles btnShow.Click
        picHours.Visible = True

    End Sub

    Private Sub btnHide_Click(sender As Object, e As EventArgs) Handles btnHide.Click
        picHours.Visible = False

    End Sub
End Class
