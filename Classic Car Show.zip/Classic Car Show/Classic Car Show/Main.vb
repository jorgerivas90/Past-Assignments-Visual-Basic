﻿Public Class Main

    Private _strCarNames(10) As String
    Private _decCarValue(10) As Decimal

    Private Sub Main_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'Reserbe memoery and poluate data

        _strCarNames = {"30 Ford Hiboy", "34 Plymouth Coupe Steel Body", "54 MG Roadster", "55 Chevy Bel Air", "55 Ford Fairlane", "55 Ford Thunderbird", "57 Jaguar XK150", "59 Edsel Corsair Convertible", "59 Volkswagen Beetle Classic", "60 Chevy Pickup Apache Truck", "63 Cadillac Eldorado"}
        _decCarValue = {26300, 79900, 27899, 99900, 34500, 74700, 36888, 22800, 39500, 45800, 44770}
        'populate data
        Dim strLoopItem As String
        For Each strLoopItem In _strCarNames
            lstCars.Items.Add(strLoopItem)
        Next
        lblTotalValue.Text = "$000000.00"
        lblCarCount.Text = "00000"

    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub btnCompute_Click(sender As Object, e As EventArgs) Handles btnCompute.Click
        ' Te btnInventory click event displays the car inventory

        Dim strItem As String 'used to manage loop through array
        Dim intCounter As Integer = 0 ' keeps track of number of cars
        Dim decTotalValue As Decimal = 0D 'keeps track of value of cars

        'computes the inventory total amount
        For Each strItem In _strCarNames
            decTotalValue += _decCarValue(intCounter)
            intCounter += 1
        Next
        'display to user
        lblCarCount.Text = intCounter.ToString("N0")
        lblTotalValue.Text = decTotalValue.ToString("C0")
    End Sub

    Private Sub lstCars_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lstCars.SelectedIndexChanged
        Dim intItemSelected As Integer ' item seleected on screen is used as subscript into array
        Dim decTotalValue As Decimal = 0D ' holds value of car selected

        intItemSelected = lstCars.SelectedIndex ' tells which was selected
        decTotalValue = _decCarValue(intItemSelected) ' extracts value from index position in array

        lblTotalValue.Text = decTotalValue.ToString ' display car value
        lblCarCount.Text = "1" ' sers car count to 1


    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        lblTotalValue.Text = "$000000.00"
        lblCarCount.Text = "00000"
    End Sub
End Class
