﻿Public Class Form1
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        txtNumTickets.Clear()
        lblTotalCostValue.Text = ("")
        txtNumTickets.Focus()
    End Sub

    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        'allocate memory
        Dim intNumTickets As Integer
        Dim decTotalPrice As Decimal


        'Get data from screen and store in memory
        intNumTickets = Convert.ToInt32(txtNumTickets.Text)


        'Perform cost calculation
        decTotalPrice = intNumTickets * 12.99

        'Display Price on screen

        lblTotalCostValue.Text = decTotalPrice.ToString("C2")

    End Sub
End Class
