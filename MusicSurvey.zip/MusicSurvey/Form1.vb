﻿Public Class Form1

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub btnReggaeton_CheckedChanged(sender As Object, e As EventArgs) Handles btnReggaeton.CheckedChanged
        picBand.Image = My.Resources.BadBunny
        lblHeader2.Text = "Bad Bunny Dakiti"

    End Sub

    Private Sub btnDreamPop_CheckedChanged(sender As Object, e As EventArgs) Handles btnDreamPop.CheckedChanged
        picBand.Image = My.Resources.BeachHouse
        lblHeader2.Text = "BeachHouse - Space Song"
    End Sub

    Private Sub btnHipHop_CheckedChanged(sender As Object, e As EventArgs) Handles btnHipHop.CheckedChanged
        picBand.Image = My.Resources.MFDOOM
        lblHeader2.Text = "MF DOOM - All Caps"
    End Sub
End Class
