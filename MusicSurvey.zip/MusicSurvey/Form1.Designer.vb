﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.btnReggaeton = New System.Windows.Forms.RadioButton()
        Me.btnDreamPop = New System.Windows.Forms.RadioButton()
        Me.btnHipHop = New System.Windows.Forms.RadioButton()
        Me.btnSubmit = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.lblHeader = New System.Windows.Forms.Label()
        Me.picBand = New System.Windows.Forms.PictureBox()
        Me.lblHeader2 = New System.Windows.Forms.Label()
        CType(Me.picBand, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnReggaeton
        '
        Me.btnReggaeton.AutoSize = True
        Me.btnReggaeton.Location = New System.Drawing.Point(76, 82)
        Me.btnReggaeton.Name = "btnReggaeton"
        Me.btnReggaeton.Size = New System.Drawing.Size(123, 29)
        Me.btnReggaeton.TabIndex = 0
        Me.btnReggaeton.TabStop = True
        Me.btnReggaeton.Text = "Reggaeton"
        Me.btnReggaeton.UseVisualStyleBackColor = True
        '
        'btnDreamPop
        '
        Me.btnDreamPop.AutoSize = True
        Me.btnDreamPop.Location = New System.Drawing.Point(76, 213)
        Me.btnDreamPop.Name = "btnDreamPop"
        Me.btnDreamPop.Size = New System.Drawing.Size(126, 29)
        Me.btnDreamPop.TabIndex = 1
        Me.btnDreamPop.TabStop = True
        Me.btnDreamPop.Text = "Dream Pop"
        Me.btnDreamPop.UseVisualStyleBackColor = True
        '
        'btnHipHop
        '
        Me.btnHipHop.AutoSize = True
        Me.btnHipHop.Location = New System.Drawing.Point(76, 333)
        Me.btnHipHop.Name = "btnHipHop"
        Me.btnHipHop.Size = New System.Drawing.Size(107, 29)
        Me.btnHipHop.TabIndex = 2
        Me.btnHipHop.TabStop = True
        Me.btnHipHop.Text = "Hip-Hop"
        Me.btnHipHop.UseVisualStyleBackColor = True
        '
        'btnSubmit
        '
        Me.btnSubmit.Location = New System.Drawing.Point(312, 393)
        Me.btnSubmit.Name = "btnSubmit"
        Me.btnSubmit.Size = New System.Drawing.Size(148, 51)
        Me.btnSubmit.TabIndex = 4
        Me.btnSubmit.Text = "Submit"
        Me.btnSubmit.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(231, -154)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(63, 25)
        Me.Label1.TabIndex = 5
        Me.Label1.Text = "Label1"
        '
        'lblHeader
        '
        Me.lblHeader.AutoSize = True
        Me.lblHeader.Location = New System.Drawing.Point(350, -148)
        Me.lblHeader.Name = "lblHeader"
        Me.lblHeader.Size = New System.Drawing.Size(0, 25)
        Me.lblHeader.TabIndex = 6
        '
        'picBand
        '
        Me.picBand.Location = New System.Drawing.Point(374, 82)
        Me.picBand.Name = "picBand"
        Me.picBand.Size = New System.Drawing.Size(335, 280)
        Me.picBand.TabIndex = 7
        Me.picBand.TabStop = False
        '
        'lblHeader2
        '
        Me.lblHeader2.AutoSize = True
        Me.lblHeader2.Font = New System.Drawing.Font("Showcard Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.lblHeader2.Location = New System.Drawing.Point(374, 23)
        Me.lblHeader2.Name = "lblHeader2"
        Me.lblHeader2.Size = New System.Drawing.Size(0, 30)
        Me.lblHeader2.TabIndex = 8
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(10.0!, 25.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(783, 484)
        Me.Controls.Add(Me.lblHeader2)
        Me.Controls.Add(Me.picBand)
        Me.Controls.Add(Me.lblHeader)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.btnSubmit)
        Me.Controls.Add(Me.btnHipHop)
        Me.Controls.Add(Me.btnDreamPop)
        Me.Controls.Add(Me.btnReggaeton)
        Me.Name = "Form1"
        Me.Text = "Music Survey"
        CType(Me.picBand, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnReggaeton As RadioButton
    Friend WithEvents btnDreamPop As RadioButton
    Friend WithEvents btnHipHop As RadioButton
    Friend WithEvents btnSubmit As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents lblHeader As Label
    Friend WithEvents picBand As PictureBox
    Friend WithEvents lblHeader2 As Label
End Class
