﻿Option Explicit On
Option Strict Off
Option Infer Off
Public Class MainForm
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub MainForm_FormClosing(sender As Object, e As FormClosingEventArgs)
        'Verify that the user wants to exit the application

        Dim dlgButton As DialogResult
        'dlgButton = MessageBox.Show("Do you want To Exit?",
        ' MessageBoxButtons.YesNo,
        '  MessageBoxIcon.Exclamation)
        'If the No button is selected, do not close the form.
        If dlgButton = DialogResult.No Then
            e.Cancel = True
        End If
    End Sub

    Private Sub btnTranslate_Click(sender As Object, e As EventArgs) Handles btnTranslate.Click


        If radMother.Checked AndAlso cboLanguages.SelectedItem = "Spanish" Then
            lblTranslate.Text = "Madre"
        ElseIf radFather.Checked AndAlso cboLanguages.SelectedItem = "Spanish" Then
            lblTranslate.Text = "Padre"
        ElseIf radSister.Checked AndAlso cboLanguages.SelectedItem = "Spanish" Then
            lblTranslate.Text = "Hermana"
        ElseIf radBrother.Checked AndAlso cboLanguages.SelectedItem = "Spanish" Then
            lblTranslate.Text = "Hermano"
        ElseIf radMother.Checked AndAlso cboLanguages.SelectedItem = "Italian" Then
            lblTranslate.Text = "Madre"
        ElseIf radFather.Checked AndAlso cboLanguages.SelectedItem = "Italian" Then
            lblTranslate.Text = "Padre"
        ElseIf radSister.Checked AndAlso cboLanguages.SelectedItem = "Italian" Then
            lblTranslate.Text = "Sorella"
        ElseIf radBrother.Checked AndAlso cboLanguages.SelectedItem = "Italian" Then
            lblTranslate.Text = "Fratello"
        ElseIf radMother.Checked AndAlso cboLanguages.SelectedItem = "French" Then
            lblTranslate.Text = "Mere"
        ElseIf radFather.Checked AndAlso cboLanguages.SelectedItem = "French" Then
            lblTranslate.Text = "Pere"
        ElseIf radSister.Checked AndAlso cboLanguages.SelectedItem = "French" Then
            lblTranslate.Text = "Soeur"
        ElseIf radBrother.Checked AndAlso cboLanguages.SelectedItem = "French" Then
            lblTranslate.Text = "Frere"
        End If

    End Sub

End Class
