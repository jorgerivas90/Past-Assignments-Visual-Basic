﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MainForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnTranslate = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.lblTranslate = New System.Windows.Forms.Label()
        Me.cboLanguages = New System.Windows.Forms.ComboBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.radBrother = New System.Windows.Forms.RadioButton()
        Me.radSister = New System.Windows.Forms.RadioButton()
        Me.radFather = New System.Windows.Forms.RadioButton()
        Me.radMother = New System.Windows.Forms.RadioButton()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnTranslate
        '
        Me.btnTranslate.Location = New System.Drawing.Point(612, 62)
        Me.btnTranslate.Name = "btnTranslate"
        Me.btnTranslate.Size = New System.Drawing.Size(107, 43)
        Me.btnTranslate.TabIndex = 0
        Me.btnTranslate.Text = "Translate"
        Me.btnTranslate.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(612, 123)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(107, 43)
        Me.btnExit.TabIndex = 1
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(305, 32)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(105, 20)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "Translates to:"
        '
        'lblTranslate
        '
        Me.lblTranslate.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblTranslate.Location = New System.Drawing.Point(285, 182)
        Me.lblTranslate.Name = "lblTranslate"
        Me.lblTranslate.Size = New System.Drawing.Size(192, 86)
        Me.lblTranslate.TabIndex = 4
        '
        'cboLanguages
        '
        Me.cboLanguages.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboLanguages.FormattingEnabled = True
        Me.cboLanguages.Items.AddRange(New Object() {"Spanish", "French", "Italian"})
        Me.cboLanguages.Location = New System.Drawing.Point(309, 62)
        Me.cboLanguages.Name = "cboLanguages"
        Me.cboLanguages.Size = New System.Drawing.Size(121, 28)
        Me.cboLanguages.TabIndex = 5
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.radBrother)
        Me.GroupBox1.Controls.Add(Me.radSister)
        Me.GroupBox1.Controls.Add(Me.radFather)
        Me.GroupBox1.Controls.Add(Me.radMother)
        Me.GroupBox1.Location = New System.Drawing.Point(35, 32)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(164, 246)
        Me.GroupBox1.TabIndex = 6
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "English"
        '
        'radBrother
        '
        Me.radBrother.AutoSize = True
        Me.radBrother.Location = New System.Drawing.Point(10, 150)
        Me.radBrother.Name = "radBrother"
        Me.radBrother.Size = New System.Drawing.Size(87, 24)
        Me.radBrother.TabIndex = 13
        Me.radBrother.Text = "Brother"
        Me.radBrother.UseVisualStyleBackColor = True
        '
        'radSister
        '
        Me.radSister.AutoSize = True
        Me.radSister.Location = New System.Drawing.Point(10, 110)
        Me.radSister.Name = "radSister"
        Me.radSister.Size = New System.Drawing.Size(75, 24)
        Me.radSister.TabIndex = 11
        Me.radSister.Text = "Sister"
        Me.radSister.UseVisualStyleBackColor = True
        '
        'radFather
        '
        Me.radFather.AutoSize = True
        Me.radFather.Location = New System.Drawing.Point(10, 70)
        Me.radFather.Name = "radFather"
        Me.radFather.Size = New System.Drawing.Size(81, 24)
        Me.radFather.TabIndex = 9
        Me.radFather.Text = "Father"
        Me.radFather.UseVisualStyleBackColor = True
        '
        'radMother
        '
        Me.radMother.AutoSize = True
        Me.radMother.Checked = True
        Me.radMother.Location = New System.Drawing.Point(10, 31)
        Me.radMother.Name = "radMother"
        Me.radMother.Size = New System.Drawing.Size(84, 24)
        Me.radMother.TabIndex = 7
        Me.radMother.TabStop = True
        Me.radMother.Text = "Mother"
        Me.radMother.UseVisualStyleBackColor = True
        '
        'MainForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.cboLanguages)
        Me.Controls.Add(Me.lblTranslate)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnTranslate)
        Me.Name = "MainForm"
        Me.Text = "Translator"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnTranslate As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents lblTranslate As Label
    Friend WithEvents cboLanguages As ComboBox
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents radBrother As RadioButton
    Friend WithEvents radSister As RadioButton
    Friend WithEvents radFather As RadioButton
    Friend WithEvents radMother As RadioButton
End Class
