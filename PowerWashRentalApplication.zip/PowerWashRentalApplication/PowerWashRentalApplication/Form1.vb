﻿Public Class Form1
    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        'Delcare memory for Data
        Dim blnHDChosen As Boolean
        Dim blnFDChosen As Boolean
        Dim blnTwoDayChosen As Boolean

        Dim decTotalCostAmt As Decimal

        Dim decHDCost As Decimal = 24D
        Dim decFDCost As Decimal = 35D
        Dim decTwoDayCost As Decimal = 50D

        'Get Data from screen and place in memory variables
        blnHDChosen = optHalfDay.Checked
        blnFDChosen = optFullDay.Checked
        blnTwoDayChosen = optTwoDay.Checked

        'Determine which option was selected

        If blnHDChosen = True Then
            decTotalCostAmt = decHDCost
        ElseIf blnFDChosen = True Then
            decTotalCostAmt = decFDCost
        Else
            decTotalCostAmt = decTwoDayCost
        End If

        'Display Cost on the screen

        lblCostAmount.Text = decTotalCostAmt.ToString("C2")

    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        lblCostAmount.Text = ""
        optHalfDay.Checked = False
        optFullDay.Checked = False
        optTwoDay.Checked = False
    End Sub
End Class
