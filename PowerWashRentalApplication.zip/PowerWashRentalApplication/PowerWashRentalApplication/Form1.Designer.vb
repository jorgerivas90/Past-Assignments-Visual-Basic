﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.btnCalculate = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.optHalfDay = New System.Windows.Forms.RadioButton()
        Me.lblTitle = New System.Windows.Forms.Label()
        Me.lblCost = New System.Windows.Forms.Label()
        Me.lblCostAmount = New System.Windows.Forms.Label()
        Me.optFullDay = New System.Windows.Forms.RadioButton()
        Me.optTwoDay = New System.Windows.Forms.RadioButton()
        Me.imgPowerWash = New System.Windows.Forms.PictureBox()
        CType(Me.imgPowerWash, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnCalculate
        '
        Me.btnCalculate.Location = New System.Drawing.Point(117, 308)
        Me.btnCalculate.Name = "btnCalculate"
        Me.btnCalculate.Size = New System.Drawing.Size(109, 44)
        Me.btnCalculate.TabIndex = 0
        Me.btnCalculate.Text = "Calculate"
        Me.btnCalculate.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(256, 308)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(108, 44)
        Me.btnClear.TabIndex = 1
        Me.btnClear.Text = "Clear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'optHalfDay
        '
        Me.optHalfDay.AutoSize = True
        Me.optHalfDay.Location = New System.Drawing.Point(117, 101)
        Me.optHalfDay.Name = "optHalfDay"
        Me.optHalfDay.Size = New System.Drawing.Size(95, 24)
        Me.optHalfDay.TabIndex = 2
        Me.optHalfDay.TabStop = True
        Me.optHalfDay.Text = "Half Day"
        Me.optHalfDay.UseVisualStyleBackColor = True
        '
        'lblTitle
        '
        Me.lblTitle.AutoSize = True
        Me.lblTitle.Location = New System.Drawing.Point(113, 33)
        Me.lblTitle.Name = "lblTitle"
        Me.lblTitle.Size = New System.Drawing.Size(149, 20)
        Me.lblTitle.TabIndex = 3
        Me.lblTitle.Text = "Power Wash Rental"
        '
        'lblCost
        '
        Me.lblCost.AutoSize = True
        Me.lblCost.Location = New System.Drawing.Point(113, 242)
        Me.lblCost.Name = "lblCost"
        Me.lblCost.Size = New System.Drawing.Size(85, 20)
        Me.lblCost.TabIndex = 4
        Me.lblCost.Text = "Total Cost:"
        '
        'lblCostAmount
        '
        Me.lblCostAmount.AutoSize = True
        Me.lblCostAmount.Location = New System.Drawing.Point(239, 242)
        Me.lblCostAmount.Name = "lblCostAmount"
        Me.lblCostAmount.Size = New System.Drawing.Size(0, 20)
        Me.lblCostAmount.TabIndex = 5
        '
        'optFullDay
        '
        Me.optFullDay.AutoSize = True
        Me.optFullDay.Location = New System.Drawing.Point(117, 148)
        Me.optFullDay.Name = "optFullDay"
        Me.optFullDay.Size = New System.Drawing.Size(91, 24)
        Me.optFullDay.TabIndex = 6
        Me.optFullDay.TabStop = True
        Me.optFullDay.Text = "Full Day"
        Me.optFullDay.UseVisualStyleBackColor = True
        '
        'optTwoDay
        '
        Me.optTwoDay.AutoSize = True
        Me.optTwoDay.Location = New System.Drawing.Point(117, 200)
        Me.optTwoDay.Name = "optTwoDay"
        Me.optTwoDay.Size = New System.Drawing.Size(132, 24)
        Me.optTwoDay.TabIndex = 7
        Me.optTwoDay.TabStop = True
        Me.optTwoDay.Text = "Two Full Days"
        Me.optTwoDay.UseVisualStyleBackColor = True
        '
        'imgPowerWash
        '
        Me.imgPowerWash.Image = CType(resources.GetObject("imgPowerWash.Image"), System.Drawing.Image)
        Me.imgPowerWash.Location = New System.Drawing.Point(363, 46)
        Me.imgPowerWash.Name = "imgPowerWash"
        Me.imgPowerWash.Size = New System.Drawing.Size(294, 245)
        Me.imgPowerWash.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.imgPowerWash.TabIndex = 8
        Me.imgPowerWash.TabStop = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.imgPowerWash)
        Me.Controls.Add(Me.optTwoDay)
        Me.Controls.Add(Me.optFullDay)
        Me.Controls.Add(Me.lblCostAmount)
        Me.Controls.Add(Me.lblCost)
        Me.Controls.Add(Me.lblTitle)
        Me.Controls.Add(Me.optHalfDay)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnCalculate)
        Me.Name = "Form1"
        Me.Text = "Form1"
        CType(Me.imgPowerWash, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnCalculate As Button
    Friend WithEvents btnClear As Button
    Friend WithEvents optHalfDay As RadioButton
    Friend WithEvents lblTitle As Label
    Friend WithEvents lblCost As Label
    Friend WithEvents lblCostAmount As Label
    Friend WithEvents optFullDay As RadioButton
    Friend WithEvents optTwoDay As RadioButton
    Friend WithEvents imgPowerWash As PictureBox
End Class
