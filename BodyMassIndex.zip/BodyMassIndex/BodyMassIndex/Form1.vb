﻿Public Class Form1
    Private Sub btnCompute_Click(sender As Object, e As EventArgs) Handles btnCompute.Click
        Dim decHeight As Decimal
        Dim decWeight As Decimal
        Dim decAnswer As Decimal
        Dim intCBIndex As Integer

        Decimal.TryParse(txtHeight.Text, decHeight)
        Decimal.TryParse(txtWeight.Text, decWeight)
        intCBIndex = cboSystem.SelectedIndex '0 for imperial 1 for Metric

        decAnswer = CalcBMI(decHeight, decWeight, intCBIndex)

        lblAnswer.Text = decAnswer.ToString("N2")


    End Sub

    Private Function CalcBMI(ByVal decH As Decimal, ByVal decW As Decimal, ByVal intCB As Integer) As Decimal
        Dim decBMI As Decimal
        If intCB = 0 Then
            decBMI = (decW / (decH * decH)) * 703
        Else
            decBMI = (decW / (decH * decH))
        End If
        Return decBMI
    End Function
End Class
