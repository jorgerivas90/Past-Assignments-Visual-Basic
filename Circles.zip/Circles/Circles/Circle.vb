﻿Public Class Circle
    Private _radius As Double

    Public Property Radius As Double
        Get
            Return _radius
        End Get
        Set(value As Double)
            _radius = value
        End Set
    End Property

    Public Sub New()
        _radius = 0
    End Sub

    Public Sub New(ByVal r As Double)
        Radius = r
    End Sub

    Public Function GetArea() As Double
        Return 3.141592 * _radius ^ 2
    End Function
End Class
