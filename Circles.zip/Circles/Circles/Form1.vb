﻿Public Class Form1
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        Dim dblArea As Double
        Dim dblRadius As Double
        Double.TryParse(txtRadius.Text, dblRadius)
        Dim MyCircle As New Circle(dblRadius)
        dblArea = MyCircle.GetArea()
        lblArea.Text = dblArea.ToString("N2")
    End Sub
End Class
