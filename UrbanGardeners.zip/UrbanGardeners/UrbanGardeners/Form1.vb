﻿Public Class Form1
    Private Sub PlotHolderBindingNavigatorSaveItem_Click(sender As Object, e As EventArgs) 
        Me.Validate()
        Me.PlotHolderBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.GardenersDataSet)

    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'GardenersDataSet.PlotHolder' table. You can move, or remove it, as needed.
        Me.PlotHolderTableAdapter.Fill(Me.GardenersDataSet.PlotHolder)

    End Sub
End Class
