﻿' Name:         Seminars Project
' Purpose:      Calculate and display the amount due.
' Programmer:   Jorge Rivas on 3/19/2021

Option Explicit On
Option Strict On
Option Infer Off

Public Class frmMain
    Private Sub btnCalc_Click(sender As Object, e As EventArgs) Handles btnCalc.Click
        ' Calculate and display the amount due.

        Dim intAmountDue As Integer

        ' Determine which (if any) check boxes are selected
        ' and add the associated fee to the amount due.
        If chkFinance.Checked = True Then
            intAmountDue = intAmountDue + 150
        End If

        If chkHealth.Checked = True Then
            intAmountDue = intAmountDue + 125
        End If

        If chkMarketing.Checked = True Then
            intAmountDue = intAmountDue + 135
        End If

        lblAmountDue.Text = intAmountDue.ToString("C0")
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

End Class
