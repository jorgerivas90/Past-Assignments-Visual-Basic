﻿' Name:         Pizzeria Project
' Purpose:      Display the number of square pizza slices that can be cut from a square pizza.
' Programmer:   Jorge on 5/20/2021

Option Explicit On
Option Strict On
Option Infer Off

Public Class frmMain

    Private Sub btnCalc_Click(sender As Object, e As EventArgs) Handles btnCalc.Click
        ' Displays the number of square pizza slices.

        ' Declare variables.
        Dim entirePizza As Rectangle
        Dim pizzaSlice As Rectangle
        Dim intEntireSide As Integer
        Dim intSliceSide As Integer
        Dim intEntireArea As Integer
        Dim intSliceArea As Integer
        Dim dblSlices As Double

        Integer.TryParse(txtEntireSide.Text, intEntireSide)
        Integer.TryParse(txtSliceSide.Text, intSliceSide)
        If intEntireSide > 0 AndAlso intSliceSide > 0 Then
            'Instantiate and initilize objects
            entirePizza = New Rectangle(intEntireSide, intEntireSide)
            pizzaSlice = New Rectangle(intSliceSide, intSliceSide)
            'Calculate Area
            intEntireArea = entirePizza.GetArea
            intSliceArea = pizzaSlice.GetArea
            'Calculate number of slices
            dblSlices = intEntireArea / intSliceArea
        End If

        ' Display number of slices.
        lblSlices.Text = dblSlices.ToString("N1")
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub txtEntireSide_Enter(sender As Object, e As EventArgs) Handles txtEntireSide.Enter
        txtEntireSide.SelectAll()
    End Sub

    Private Sub txtSliceSide_Enter(sender As Object, e As EventArgs) Handles txtSliceSide.Enter
        txtSliceSide.SelectAll()
    End Sub

    Private Sub CancelKeys(sender As Object, e As KeyPressEventArgs) Handles txtEntireSide.KeyPress, txtSliceSide.KeyPress
        ' Accept only numbers and the Backspace key.

        If (e.KeyChar < "0" OrElse e.KeyChar > "9") AndAlso e.KeyChar <> ControlChars.Back Then
            e.Handled = True
        End If
    End Sub

    Private Sub ClearSlices(sender As Object, e As EventArgs) Handles txtEntireSide.TextChanged, txtSliceSide.TextChanged
        lblSlices.Text = String.Empty
    End Sub
End Class
