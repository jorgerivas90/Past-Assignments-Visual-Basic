﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmMain))
        Me.btnShow = New System.Windows.Forms.Button()
        Me.btnHide = New System.Windows.Forms.Button()
        Me.picEinstein = New System.Windows.Forms.PictureBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.picEquation = New System.Windows.Forms.PictureBox()
        Me.btnExit = New System.Windows.Forms.Button()
        CType(Me.picEinstein, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picEquation, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnShow
        '
        Me.btnShow.Location = New System.Drawing.Point(28, 296)
        Me.btnShow.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btnShow.Name = "btnShow"
        Me.btnShow.Size = New System.Drawing.Size(184, 41)
        Me.btnShow.TabIndex = 1
        Me.btnShow.Text = "&Show equation"
        Me.btnShow.UseVisualStyleBackColor = True
        '
        'btnHide
        '
        Me.btnHide.Location = New System.Drawing.Point(218, 296)
        Me.btnHide.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btnHide.Name = "btnHide"
        Me.btnHide.Size = New System.Drawing.Size(184, 41)
        Me.btnHide.TabIndex = 2
        Me.btnHide.Text = "&Hide equation"
        Me.btnHide.UseVisualStyleBackColor = True
        '
        'picEinstein
        '
        Me.picEinstein.Image = Global.Einstein_Project.My.Resources.Resources.Einstein
        Me.picEinstein.Location = New System.Drawing.Point(51, 30)
        Me.picEinstein.Name = "picEinstein"
        Me.picEinstein.Size = New System.Drawing.Size(184, 242)
        Me.picEinstein.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picEinstein.TabIndex = 3
        Me.picEinstein.TabStop = False
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(-126, 125)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(100, 50)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 4
        Me.PictureBox1.TabStop = False
        '
        'picEquation
        '
        Me.picEquation.Image = CType(resources.GetObject("picEquation.Image"), System.Drawing.Image)
        Me.picEquation.Location = New System.Drawing.Point(350, 115)
        Me.picEquation.Name = "picEquation"
        Me.picEquation.Size = New System.Drawing.Size(230, 50)
        Me.picEquation.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picEquation.TabIndex = 5
        Me.picEquation.TabStop = False
        Me.picEquation.Visible = False
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(464, 296)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(116, 41)
        Me.btnExit.TabIndex = 6
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(11.0!, 28.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(668, 380)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.picEquation)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.picEinstein)
        Me.Controls.Add(Me.btnHide)
        Me.Controls.Add(Me.btnShow)
        Me.Font = New System.Drawing.Font("Segoe UI", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.MaximizeBox = False
        Me.Name = "frmMain"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Einstein's Famous Equation"
        CType(Me.picEinstein, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picEquation, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents btnShow As Button
    Friend WithEvents btnHide As Button
    Friend WithEvents picEinstein As PictureBox
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents picEquation As PictureBox
    Friend WithEvents btnExit As Button
End Class
