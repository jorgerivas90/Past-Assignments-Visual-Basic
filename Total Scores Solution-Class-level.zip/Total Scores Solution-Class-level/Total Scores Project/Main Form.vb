﻿' Name:         Total Score Solution
' Purpose:      Accumulates and displays the scores.
' Programmer:   Jorge on 03/07/2021

Option Explicit On
Option Strict On
Option Infer Off

Public Class frmMain
    'Class level variable for accumlating scores.
    Private dblTotal As Double
    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        ' Accumulates and displays the scores.

        ' Procedure-level variable for storing a score.
        Dim dblScore As Double

        'Static Varibale for acuumlating scores.
        Static dblTotal As Double

        ' Accumulate the scores and display the results.
        Double.TryParse(txtScore.Text, dblScore)
        dblTotal = dblTotal + dblScore
        lblTotal.Text = dblTotal.ToString
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class
